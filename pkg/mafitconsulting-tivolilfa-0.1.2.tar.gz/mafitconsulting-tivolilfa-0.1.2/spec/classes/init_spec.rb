require 'spec_helper'
describe 'tivolilfa' do
  context 'with default values for all parameters' do
    it { should contain_class('tivolilfa') }
  end
end
